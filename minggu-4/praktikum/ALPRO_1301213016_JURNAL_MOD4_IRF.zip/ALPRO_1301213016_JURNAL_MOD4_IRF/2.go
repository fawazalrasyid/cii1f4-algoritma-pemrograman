package main

import "fmt"

func main() {

	var N, d1, d0 int
	var status bool = true

	fmt.Scan(&N)

	d1 = N & 10
	d0 = d1
	N = N % 10

	for N > 0 && status {
		d1 = N % 10
		status = (d1-d0) == 1 || (d0-d1) == 1
		d0 = d1
		N = N / 10
	}

	fmt.Print(status)
}
